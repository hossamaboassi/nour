import React from 'react';

const QuranExperience = () => (
  <div>
    <h2>Quran Experience</h2>
    <p>Feature coming soon</p>
  </div>
);

export default QuranExperience;