import React from 'react';

const HadithSection = () => (
  <div>
    <h2>Hadith Section</h2>
    <p>Coming soon</p>
  </div>
);

export default HadithSection;