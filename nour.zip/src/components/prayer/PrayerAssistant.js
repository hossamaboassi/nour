import React from 'react';

const PrayerAssistant = () => (
  <div>
    <h2>Prayer Assistant</h2>
    <p>Coming soon</p>
  </div>
);

export default PrayerAssistant;