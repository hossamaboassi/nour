import React from 'react';

const LearnIslamSection = () => (
  <div>
    <h2>Learn Islam</h2>
    <p>Coming soon</p>
  </div>
);

export default LearnIslamSection;