import React from 'react';

const DailyInspiration = () => (
  <div style={{ padding: '1rem', border: '1px solid #ddd', marginBottom: '1rem' }}>
    <h3>Today's Inspiration</h3>
    <p>Patience is a pillar of faith</p>
  </div>
);

export default DailyInspiration;