import React from 'react';

const Header = () => (
  <header style={{ padding: '1rem', backgroundColor: '#f0f0f0' }}>
    <h1>NOUR App</h1>
  </header>
);

export default Header;