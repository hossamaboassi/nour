import React from 'react';

const Footer = () => (
  <footer style={{ padding: '1rem', backgroundColor: '#f0f0f0', marginTop: '2rem' }}>
    <p>© 2023 NOUR App</p>
  </footer>
);

export default Footer;