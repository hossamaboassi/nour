import React from 'react';

const CommunityFeatures = () => (
  <div>
    <h2>Community</h2>
    <p>Coming soon</p>
  </div>
);

export default CommunityFeatures;