import OnboardingScreen from './components/onboarding/OnboardingScreen';

function App() {
  return <OnboardingScreen />;
}

export default App;